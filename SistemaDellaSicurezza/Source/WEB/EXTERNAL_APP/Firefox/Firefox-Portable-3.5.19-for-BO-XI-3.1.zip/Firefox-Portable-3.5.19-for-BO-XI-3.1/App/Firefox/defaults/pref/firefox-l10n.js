//@line 36 "e:\builds\moz2_slave\rel-191-w32-rpk-3\l10n-mozilla-1.9.1\it\browser\firefox-l10n.js"

//@line 38 "e:\builds\moz2_slave\rel-191-w32-rpk-3\l10n-mozilla-1.9.1\it\browser\firefox-l10n.js"

pref("general.useragent.locale", "it");
