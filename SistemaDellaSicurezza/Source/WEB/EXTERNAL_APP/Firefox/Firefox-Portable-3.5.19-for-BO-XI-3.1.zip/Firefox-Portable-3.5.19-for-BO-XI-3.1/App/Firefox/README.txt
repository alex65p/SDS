Per informazioni sull'installazione, l'avvio e la configurazione di
Firefox, incluso un elenco dei problemi noti e varie soluzioni, fare
riferimento a: http://getfirefox.com/releases/